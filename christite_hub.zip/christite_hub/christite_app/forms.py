# from .models import User_Profile
# from django import forms
#
# class UserProfileForm(forms.ModelForm):
#     profile_pic = forms.CharField(label="",max_length=50,widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Profile Pic'}))
#     designation = forms.CharField(label="",max_length=50,widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Designation'}))
#     cover_image = forms.CharField(label="",max_length=50,widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Cover Image'}))
#     class Meta:
#         model=User_Profile
#         exclude=("user",)