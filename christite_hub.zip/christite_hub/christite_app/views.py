from django.shortcuts import render
from django.http import HttpResponse
from django.contrib import messages
from django.contrib.auth import logout
from django.db import IntegrityError
# Create your views here.
# social_media/views.py

from django.shortcuts import render
# from .models import Post,Comment
from .models import Post
from .models import User,User_Profile,Post,Comment
from . import views

from django.shortcuts import render, redirect
# from django.contrib.auth import authenticate, login as auth_login
from django.contrib.auth import authenticate, login as auth_login
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.utils import timezone



def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['pass']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            # login(request, user)
            auth_login(request, user)
            # Redirect to a success page.
            # return redirect('home')
            return redirect('home1')
        else:
            # Return an 'invalid login' error message.
            messages.error(request, 'Invalid username or password.')
    return render(request, 'login_copy.html')

# @login_required
# def home(request):
#     if not request.user.is_authenticated:
#         # If user is not authenticated, display a message and redirect to login page
#         messages.error(request, "You need to login first.")
#         return redirect('login')
#     posts = Post.objects.all()
#     current_user = request.user
#     profile = Profile.objects.filter(user=current_user)
#     profile_pic=profile[0].profile_pic
#     return render(request, 'home.html', {'posts': posts,'current_user':current_user,'profile_pic':profile_pic})

@login_required
def home1(request):
    post_detail=None
    getComment=None
    if not request.user.is_authenticated:
        # If user is not authenticated, display a message and redirect to login page
        messages.error(request, "You need to login first.")
        return redirect('login')
    if request.user.is_superuser:
        return render(request,'admin_page.html')
    # posts = Post.objects.all()
    current_user = request.user
    name=request.user.first_name
    profile = User_Profile.objects.filter(user=current_user)
    # print(profile)
    profile_pic=profile[0].profile_pic
    cover_image = profile[0].cover_image
    designation= profile[0].designation

    try:
        getPost=Post.objects.all().order_by('-created_at')
        print(getPost)
        # print(type(getPost[0].user))
        getComment = Comment.objects.all()
        print(getComment)
        # l1=[]
        # for com in getComment:
        #     comments={'who_commented':str(com.user),'whose_post':str(com.post),'what_commented':str(com.content)}
        #     l1.append(comments)
        # print(l1)
    except:
        pass

    return render(request, 'home_bootstrap.html', {'current_user':current_user,'profile_pic':profile_pic,'cover_image':cover_image,'designation':designation,'name':name,'getPost':getPost,'comments':getComment})


def logout_view(request):
    logout(request)
    return redirect('login')

# def register(request):
#     error_message=None
#     if request.method=='POST':
#         username=request.POST['username']
#         full_name=request.POST['name']
#         designation=request.POST['designation']
#         email=request.POST['email']
#         password=request.POST['pass']
#         image=request.FILES.get('img')
#         cover_image=request.FILES.get('cover_img')
#
#         try:
#             user=User.objects.create_user(username=username,first_name=full_name,email=email,password=password)
#         except IntegrityError:
#             error_message='User Already exists'
#         else:
#             profile=Profile(user=user,profile_pic=image,designation=designation,cover_image=cover_image)
#             profile.save()
#
#             return redirect('/')
#
#     return render(request,'registration.html',{'error_message':error_message})

def register1(request):
    error_message=None
    if request.method=='POST':
        username=request.POST['username']
        full_name=request.POST['name']
        designation=request.POST['designation']
        email=request.POST['email']
        password=request.POST['pass']
        image=request.FILES.get('img')
        cover_image=request.FILES.get('cover_img')

        try:
            user=User.objects.create_user(username=username,first_name=full_name,email=email,password=password)
        except IntegrityError:
            error_message='User Already exists'
        else:
            profile=User_Profile(user=user,profile_pic=image,designation=designation,cover_image=cover_image)
            profile.save()

            return redirect('/')

    return render(request,'registration_copy.html',{'error_message':error_message})

# @login_required
# def createPost(request):
#     if request.method=='POST':
#         content=request.POST['content']
#         post_image=request.FILES.get('post_image')
#         c_user=request.user
#         # print(c_user)
#         posting=Post(user=c_user,content=content,post_image=post_image,created_at=timezone.now())
#         posting.save()
#
#         # try:
#         #     com_user=Post.objects.filter(user=c_user)
#         #     # com_user=com_user[0]
#         #     # print(com_user[0])
#         #     # com_user=com_user[0].user
#         #     # print(com_user[0].user)
#         # except:
#         #     print('Except executed')
#         #     # pass
#         # else:
#         #     pass
#         #     com=Comment.objects.create(post=com_user[0])
#         #     com.save()
#
#         # def __str__(self):
#         #     return self.c_user
#         return redirect('/home1')
#     else:
#         pass

# def createComment(request,name):
#     if request.method=='POST':
#         # print(name)
#         user=User.objects.get(username=name)
#         # print("Hey",user)
#         post_user=Post.objects.filter(user=user)
#         comment=request.POST['comment']
#         current_u=request.user
#         created_at=timezone.now()
#
#         # print("Hey:-",current_u)
#         com_ins=Comment(user=current_u,post=post_user[0],content=comment,created_at=created_at)
#         com_ins.save()
#
#         return redirect('/home1')
#     return redirect('/home1')




#-------------------------------------------------------
#Recent
from django.shortcuts import get_object_or_404
@login_required
def createPost(request):
    if request.method == 'POST':
        content = request.POST.get('content')
        image_file = request.FILES.get('post_image')
        user = request.user
        if content or image_file:
            post = Post.objects.create(user=user, content=content, post_image=image_file,created_at=timezone.now())
            return redirect('/home1')
        else:
            messages.error(request, "Please enter content or upload an image.")
        return redirect('/home1')
    else:
        pass

@login_required
def createComment(request, post_id):
    if request.method == 'POST':
        content = request.POST.get('comment')
        user = request.user
        post = get_object_or_404(Post, pk=post_id)
        # commented_user = get_object_or_404(User, username=name)
        # post = Post.objects.filter(user=commented_user).first()
        # post = Post.objects.filter(user=commented_user).order_by('-created_at').first()
        if content:
            comment = Comment.objects.create(user=user, post=post, content=content)
            return redirect('/home1')
        else:
            messages.error(request, "Please enter a comment.")
    return redirect('/home1')

def displayfriends(request):
    friends=None
    friend_list=[]
    try:
        all_users=User.objects.all()
        allprofiles=User_Profile.objects.all()
    except:
        friends=None
    else:
        # for users in all_users:
        #     if not users.is_superuser:
        #         friends={'user_id':users.id,'first_name':users.first_name,'username':users.username,'email':users.email}
        for profiles in allprofiles:
            friends={'current_user':str(request.user),'user_id':profiles.user.id,'first_name':profiles.user.first_name,'username':profiles.user.username,'email':profiles.user.email,'profile_pic':profiles.profile_pic}
            friend_list.append(friends)
    return render(request,'displayfriends.html',{'friend_list':friend_list})

