# Create your models here.
# social_media/models.py

from django.db import models
from django.contrib.auth.models import User
class Profile(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    profile_pic=models.ImageField(upload_to='media',blank=True,null=True)
    designation=models.CharField(max_length=50,blank=True,null=True)
    cover_image=models.ImageField(upload_to='media',blank=True,null=True)


    def __str__(self):
        return self.user.username


class Post(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField(max_length=100)
    post_image = models.ImageField(upload_to='media', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=False)

    #Dont forget to uncomment this if issue arise
    # def __str__(self):
    #     return f'Post by {self.user.email}'
    def __str__(self):
        return f'Post by {self.user}'

class Comment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    # def __str__(self):
    #     return f'Comment by {self.user.username} on {self.post}'
    def __str__(self):
        return str(self.user.username)
