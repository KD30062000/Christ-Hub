from django.urls import path,include
from . import views
from .views import logout_view

urlpatterns = [
    # path('home',views.home,name='home'),
    path('home1',views.home1,name='home1'),
    path('',views.login,name='login'),
    path('logout/', logout_view, name='logout'),
    # path('register',views.register,name='register'),
    path('register1',views.register1,name='register1'),
    path('post',views.createPost,name='post'),
    path('createComment/<str:name>',views.createComment,name='createComment')
]
